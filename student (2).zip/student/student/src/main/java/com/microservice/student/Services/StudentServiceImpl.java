package com.microservice.student.Services;


import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.student.Model.Student;
import com.microservice.student.Repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService{
	
	 private final StudentRepository studentRepository;

	    @Autowired
	    public StudentServiceImpl(StudentRepository studentRepository) {
	        this.studentRepository = studentRepository;
	    }

	    @Override
	    public void saveAll(List<Student> students) {
	        studentRepository.saveAll(students);;
	    }

	    @Override
	    public Optional<String> displayHighestGrade() {
	        return studentRepository.findAll().stream()
	                .max(Comparator.comparingInt(Student::getGrade))
	                .map(Student::getName);
	    }

	    @Override
	    public List<Student> sortStudentsByName() {
	        return studentRepository.findAll().stream()
	                .sorted(Comparator.comparing(Student::getName))
	                .collect(Collectors.toList());
	    }

	    @Override
	    public List<Student> sortStudentsByGrade() {
	        return studentRepository.findAll().stream()
	                .sorted(Comparator.comparingInt(Student::getGrade).reversed())
	                .collect(Collectors.toList());
	    }
	}