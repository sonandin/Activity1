package com.microservice.student.Repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.microservice.student.Model.Student;

@Repository
public class StudentRepositoryImpl implements StudentRepository {
    private List<Student> students = new ArrayList<>();

    @Override
    public void saveAll(List<Student> students) {
        this.students.addAll(students);
    }

    @Override
    public List<Student> findAll() {
        return students;
    }
}
