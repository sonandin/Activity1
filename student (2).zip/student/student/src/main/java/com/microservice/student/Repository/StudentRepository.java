package com.microservice.student.Repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.microservice.student.Model.Student;

@Repository
public interface StudentRepository {
    void saveAll(List<Student> students);
    List<Student> findAll();
}
