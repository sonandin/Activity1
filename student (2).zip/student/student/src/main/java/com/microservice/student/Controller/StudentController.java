package com.microservice.student.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.student.Model.Student;
import com.microservice.student.Services.StudentService;

@RestController
@RequestMapping("/api/stuents")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	
	@PostMapping("/acceptStudentDetails")
	public ResponseEntity<String> acceptStudentDetails(@RequestBody List<Student> students) {
        studentService.saveAll(students);
        return ResponseEntity.ok("Student details accepted successfully");
    }

    @GetMapping("/displayHighestGrade")
    public ResponseEntity<String> displayHighestGrade() {
        Optional<String> studentName = studentService.displayHighestGrade();
        return ResponseEntity.ok(studentName.orElse("No students found"));
    }

    @GetMapping("/sortStudentByName")
    public ResponseEntity<List<Student>> sortStudentByName() {
        List<Student> sortedStudents = studentService.sortStudentsByName();
        return ResponseEntity.ok(sortedStudents);
    }

    @GetMapping("/sortStudentByGrade")
    public ResponseEntity<List<Student>> sortStudentByGrade() {
        List<Student> sortedStudents = studentService.sortStudentsByGrade();
        return ResponseEntity.ok(sortedStudents);
    }
}


