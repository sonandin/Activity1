package com.microservice.student.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.microservice.student.Model.Student;

@Service
public interface StudentService {
	void saveAll(List<Student> students);
	Optional<String> displayHighestGrade();
	List<Student> sortStudentsByName();
	List<Student> sortStudentsByGrade();

}
