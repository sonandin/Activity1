package com.Sprint3.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.Sprint3.model.User1;


public interface User1Repository extends JpaRepository<User1, Long> {

}