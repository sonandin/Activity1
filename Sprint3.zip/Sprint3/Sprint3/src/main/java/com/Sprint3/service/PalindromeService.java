package com.Sprint3.service;



public interface PalindromeService {
	public String isPalindrome(String s);

	
}
