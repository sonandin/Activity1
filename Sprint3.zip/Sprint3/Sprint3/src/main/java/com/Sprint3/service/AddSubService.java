package com.Sprint3.service;

public interface AddSubService {
	public int add(int a, int b);
	
/*public class AddService{
	public static void main(String[] args) {
		
		//AddSubService add = (int a,int b) -> a+b;
		}
	}*/

	public int sub(int a, int b);
}
