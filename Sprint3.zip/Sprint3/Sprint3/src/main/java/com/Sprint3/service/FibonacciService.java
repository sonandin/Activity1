package com.Sprint3.service;

import java.util.List;

public interface FibonacciService {

	public List<Integer> getFibonacci(int limit);
}

