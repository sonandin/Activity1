package com.microservice.employeeService;

import java.util.ArrayList;

public class ArrayLists {
	
	public static void main(String[] args) {
		
		//here am declaring the ArryaList with initial size 'n'
		ArrayList<Integer> al = new ArrayList<Integer>();
		
		for(int i=1; i<=5; i++)
			al.add(i);
		
		System.out.println(al);
		
		//remove the index 4
		al.remove(3);
		System.out.println(al);
		
		//printing the elements one by one
		
		for(int i=0; i<al.size(); i++)
			System.out.println(al.get(i)+ " ");
	}

}
